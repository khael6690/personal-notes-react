import React from "react";

const Footer = () => {
    return (
        <div className='notes-app__footer'>
            <p>2023 &copy; Khaerul Umam</p>
        </div>
    )
}

export default Footer;